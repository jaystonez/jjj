<?php
class pb_backupbuddy_ajax extends pb_backupbuddy_ajaxcore {
}
?>