<?php
backupbuddy_core::versions_confirm();

pb_backupbuddy::load_script( 'jquery' );


